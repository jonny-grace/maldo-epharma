import PharmacyRegistration from '@/Components/auth/PharmacyRegistration'
import React from 'react'

function page() {
  return (
    <div><PharmacyRegistration /></div>
  )
}

export default page