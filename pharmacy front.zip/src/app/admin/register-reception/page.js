import RegisterReception from '@/Components/Admin/RegisterReception'
import React from 'react'

function page() {
  return (
    <div><RegisterReception/></div>
  )
}

export default page